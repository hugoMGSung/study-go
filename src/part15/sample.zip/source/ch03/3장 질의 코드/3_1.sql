SELECT	bookname, price
FROM	Book;


SELECT	price, bookname
FROM	Book;