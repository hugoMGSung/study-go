SELECT	*
FROM	Book
WHERE	bookname LIKE '%축구%' AND price >= 20000;