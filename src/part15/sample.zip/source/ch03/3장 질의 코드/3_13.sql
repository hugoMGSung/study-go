SELECT	*
FROM	Book
ORDER BY	price, bookname;