SELECT	SUM(saleprice)
FROM	Orders;

SELECT	SUM(saleprice) AS 총매출
FROM	Orders;

SELECT SUM(saleprice) 총매출 FROM	Orders;

SELECT SUM(saleprice) "전체 매출" FROM Orders;