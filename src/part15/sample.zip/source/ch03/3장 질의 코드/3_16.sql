SELECT	SUM(saleprice) AS 총매출
FROM	Orders
WHERE	custid=2;