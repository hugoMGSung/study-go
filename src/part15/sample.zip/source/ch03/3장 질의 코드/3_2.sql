SELECT	bookid, bookname, publisher, price
FROM	Book;


SELECT	*
FROM	Book;