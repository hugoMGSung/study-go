SELECT	publisher
FROM	Book;

SELECT DISTINCT	publisher
FROM   Book;