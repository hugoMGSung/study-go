CREATE TABLE	NewCustomer (
  custid		INTEGER	PRIMARY KEY,
  name			VARCHAR(40),
  address		VARCHAR(40),
  phone			VARCHAR(30));
