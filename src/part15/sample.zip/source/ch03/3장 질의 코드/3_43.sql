DROP TABLE NewCustomer;
SELECT * FROM	NewCustomer;

DROP TABLE NewOrders;
DROP TABLE NewCustomer;

SELECT * FROM	newbook;
SELECT * FROM	NewCustomer;
SELECT * FROM	neworders;