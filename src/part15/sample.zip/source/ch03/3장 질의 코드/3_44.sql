INSERT INTO Book(bookid, bookname, publisher, price)
		VALUES (11, '스포츠 의학', '한솔의학서적', 90000);
        
SELECT * FROM	book;

INSERT INTO Book
		VALUES (12, '스포츠 의학', '한솔의학서적', 90000);

INSERT INTO Book(bookid, bookname, price, publisher)
		VALUES (13, '스포츠 의학', 90000, '한솔의학서적');