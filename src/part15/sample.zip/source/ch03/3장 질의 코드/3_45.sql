INSERT INTO Book(bookid, bookname, publisher)
		VALUES (14, '스포츠 의학', '한솔의학서적');
       
SELECT * FROM	book;