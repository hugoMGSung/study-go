SET SQL_SAFE_UPDATES=0;

UPDATE	Customer
SET		address ='대한민국 부산'
WHERE	custid=5;
