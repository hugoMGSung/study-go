DELETE FROM Book 
WHERE  bookid = '11'; 

SELECT * FROM	book;