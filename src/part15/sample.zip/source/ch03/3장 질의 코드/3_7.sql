SELECT	bookname, publisher
FROM	Book
WHERE	bookname LIKE '축구의 역사';