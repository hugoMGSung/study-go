SELECT	name '이름', IFNULL(phone, '연락처없음') '전화번호' 
FROM	Customer;