SELECT	bookid, REPLACE(bookname, '야구', '농구') bookname, publisher, 
		price
FROM	Book;