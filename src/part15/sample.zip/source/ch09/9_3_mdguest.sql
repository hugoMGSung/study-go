USE madangdb;
SELECT * FROM Book;

SELECT * FROM madangdb.Book;