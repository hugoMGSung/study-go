USE madangdb;
SELECT * FROM Book;