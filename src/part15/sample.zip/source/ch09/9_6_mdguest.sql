GRANT SELECT ON madangdb.Book TO mdguest2;

GRANT SELECT ON madangdb.Customer TO mdguest2;