USE madangdb;
SELECT * FROM Customer;