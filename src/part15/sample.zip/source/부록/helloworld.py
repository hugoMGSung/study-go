print ("Hello World")
